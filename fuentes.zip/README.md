# prueba ETS angular

Para poder usar este proyecto usar:

```shell
npm install
gulp default
```

Abrir en el navegador [http://localhost:4000](http://localhost:4000)

Es posible que para poder usar gulp-ruby-sass se necesite ejecutar:

```shell
[sudo] gem install sass
```