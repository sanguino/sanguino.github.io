module.exports = function ($http) {
    var service = this;

    service.getUsuarios = function () {
        $http.get('api/usuarios.json') //$http.get('api/usuarios')
            .success(successLoadUsuarios)
            .error(errorLoad);
    }

    function successLoadUsuarios(data) {
        while (service.usuarios.length > 0) {
            service.usuarios.pop();
        }

        data.usuarios.forEach(function (usuario) {
            service.usuarios.push(usuario);
        });
    }

    function errorLoad(data) {
        alert("error de conexion");
    }

    function init() {
        service.usuarios = [];
        service.getUsuarios();
    }

    init();
}
