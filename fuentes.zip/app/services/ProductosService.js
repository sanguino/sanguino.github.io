module.exports = function ProductosService($http)
    {
        var service = this;

        service.getProductos = function ()
        {
            $http.get('api/productos.json') //$http.get('/api/productos')
            .success(successLoadProyectos)
            .error(errorLoad);
        }

        function successLoadProyectos(data)
        {
            while(service.productos.length > 0)
            {
                service.productos.pop();
            }

            while(service.categorias.length > 0)
            {
                service.categorias.pop();
            }

            data.productos.forEach(function(producto)
            {
                service.productos.push(producto);
                producto.unidades = 1;

                buscaCreaCategoria(producto.categoria).productos.push(producto);

            });

        }

        function buscaCreaCategoria(categoria){
            for (var i=0; i < service.categorias.length; i++) {
                if (service.categorias[i].nombre === categoria) {
                    return service.categorias[i];
                }
            }
            service.categorias.push({nombre:categoria, productos:[]});
            return service.categorias[service.categorias.length-1];
        }

        function errorLoad(data)
        {
            alert("error de conexion");
        }

        function init ()
        {
            service.productos = [];
            service.categorias = [];
            service.getProductos();
        }

        init();
    }
