require('angular');
require('angular-route');

var HeaderController    = require('./controllers/HeaderController');
var AcercadeController  = require('./controllers/AcercadeController');
var ProductosController = require('./controllers/ProductosController');
var CarritoController   = require('./controllers/CarritoController');
var ResumenController   = require('./controllers/ResumenController');
var ProductosService    = require('./services/ProductosService');
var UsuariosService     = require('./services/UsuariosService');
var Config              = require('./Config');

angular.module  ('supermercado-ets',    ['ngRoute'])
    .controller ('HeaderController',    HeaderController)
    .controller ('AcercadeController',  AcercadeController)
    .controller ('ProductosController', ProductosController)
    .controller ('CarritoController',   CarritoController)
    .controller ('ResumenController',   ResumenController)
    .service    ('ProductosService',    ProductosService)
    .service    ('UsuariosService',     UsuariosService)
    .config     (Config);


