module.exports = function($routeProvider, $locationProvider) {
    $routeProvider
        .when('/acercade',
            {
                templateUrl: 'templates/acercade.html',
                controller: 'AcercadeController',
                controllerAs: 'acercaCtrl'
            })
        .when('/productos',
            {
                templateUrl: 'templates/productos.html',
                controller: 'ProductosController',
                controllerAs: 'prodCtrl'
            })
        .when('/resumen',
            {
                templateUrl: 'templates/resumen.html',
                controller: 'ResumenController',
                controllerAs: 'resumenCtrl'
            })
        .when('/',
            {
                redirectTo: '/acercade'
            })
        .otherwise(
            {
                redirectTo: '/acercade'
            });

    $locationProvider.html5Mode({
        enabled: false,
        requireBase: false
    });
}