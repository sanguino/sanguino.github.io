module.exports = function ($location) {
        var controller = this;

    }
