module.exports = function ($location, $rootScope) {
    var controller = this;

    if (!$rootScope.resumenCompra)
        $location.path('/productos');

    controller.comprados = $rootScope.resumenCompra.comprados;
    controller.usuario = $rootScope.resumenCompra.usuario;
    controller.total = $rootScope.resumenCompra.total;

}

