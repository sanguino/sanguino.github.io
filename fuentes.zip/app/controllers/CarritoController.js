module.exports = function ($location, UsuariosService, $scope, $rootScope) {

    var controller = this;

    controller.comprados = [];
    controller.usuarios = UsuariosService.usuarios;

    controller.checkOut = function () {
        $('#confirmarCompra').modal('show');
    }

    $scope.$on('meterProducto', function (event, producto) {
        meter(producto);
    });

    controller.pagar = function () {
        for (var i = 0; i < controller.usuarios.length; i++) {
            if (controller.usuarios[i].nombre === controller.usuario) {
                $('#confirmarCompra').modal('hide');
                $('.modal').modal('hide');
                $rootScope.resumenCompra = {};
                $rootScope.resumenCompra.comprados = controller.comprados;
                $rootScope.resumenCompra.usuario = controller.usuarios[i];
                $rootScope.resumenCompra.total = controller.getTotal();
                $location.path('resumen/');
                return;
            }
        }
        alert("Usuario no registrado, utilizar por ejemplo: " + controller.usuarios[0].nombre);
    }

    function meter(producto) {
        var comprado = buscaCreaComprado(producto);
        comprado.unidades = Number(comprado.unidades) + Number(producto.unidades);
        producto.unidades = 1;
        console.log(controller.comprados);
    }

    controller.quitar = function (comprado) {
        var i = controller.comprados.indexOf(comprado);
        controller.comprados.splice(i, 1);
    }

    controller.getTotal = function () {
        var total = 0;
        for (var i = 0; i < controller.comprados.length; i++) {
            if (controller.comprados[i].unidades != "")
                total += controller.comprados[i].producto.precio * controller.comprados[i].unidades;
        }

        return total;
    }

    controller.checkUnidades = function (comprado) {

        if (comprado.unidades == "")
            return;

        comprado.unidades = Math.max(0, comprado.unidades);
        comprado.unidades = Math.floor(comprado.unidades);

        if (comprado.unidades == 0)
            controller.quitar(comprado);
    }

    function buscaCreaComprado(producto) {
        for (var i = 0; i < controller.comprados.length; i++) {
            if (controller.comprados[i].producto.id == producto.id) {
                return controller.comprados[i];
            }
        }

        controller.comprados.push({unidades: 0, producto: producto});
        return controller.comprados[controller.comprados.length - 1];


    }
}
