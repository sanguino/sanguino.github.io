module.exports = function (ProductosService, $location, $scope) {
    var controller = this;

    controller.productos = ProductosService.productos;
    controller.categorias = ProductosService.categorias;

    controller.comprar = function (producto) {
        controller.checkUnidades (producto);

        $scope.$broadcast('meterProducto', producto);

    }

    controller.checkUnidades = function (producto) {
        if (producto.unidades == "")
            return;

        if (isNaN(producto.unidades))
            producto.unidades = 1;

        producto.unidades = Math.max(1, producto.unidades);

        producto.unidades = Math.floor(producto.unidades);
    }
}
