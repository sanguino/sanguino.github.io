module.exports = function ($location) {

    var controller = this;

    controller.getClass = function (seccion) {
        if ($location.path().substr(0, seccion.length) == seccion) {
            return "active";
        }
        else {
            return ""
        }
    }

}

